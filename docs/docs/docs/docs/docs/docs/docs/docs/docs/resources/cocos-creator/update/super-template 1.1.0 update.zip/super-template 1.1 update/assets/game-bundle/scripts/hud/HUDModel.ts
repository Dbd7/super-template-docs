import { AutoSpinStatus, HUDStatus, LockStatus, TurboStatus } from './HUDEnum';

export default class HUDModel {
    state: HUDStatus = HUDStatus.Inactive;
    turboStatus: TurboStatus = TurboStatus.Inactive;
    autoSpinStatus: AutoSpinStatus = AutoSpinStatus.Inactive;
    spinButtonLock: LockStatus = LockStatus.Unlocked;
    spaceKeyIsDown: boolean = false;
}
