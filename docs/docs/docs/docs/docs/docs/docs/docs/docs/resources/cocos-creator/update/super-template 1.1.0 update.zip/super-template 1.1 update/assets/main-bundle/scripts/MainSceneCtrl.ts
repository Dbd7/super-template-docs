import { gg } from '../../scripts/framework/gg';
import AssetLoader from '../../scripts/framework/lib/asset/AssetLoader';
import { AsyncTask, RegisterDeviceFullScreen } from '../../scripts/HelperTools';
import GameSystemManager from '../../scripts/manager/GameSystemManager';
import ModuleManager from '../../scripts/manager/ModuleManager';
import { BundleConfigs } from './configs/BundleConfigs';
import { PanelConfigs } from './configs/PanelConfigs';

const { ccclass, property } = cc._decorator;

@ccclass
export default class MainSceneCtrl extends cc.Component {
    @property(cc.Node)
    rootLayerNode: cc.Node = null;

    onLoad() {
        // GameConfig subject to change when final/real API is provide. ¯\_(ツ)_/¯
        const dummyGameConfig = {
            betDenom: {
                coins: [0.01, 0.05, 0.1, 0.25, 0.5, 1, 5, 10, 15, 20],
                defaultIndex: 2,
            },
            betLine: {
                lines: [1, 2, 3, 4, 5, 6, 7, 8, 9],
                defaultIndex: 8,
            },
            currency: 'MYR',
            playerBalance: 1000,
            defaultConvertionType: 'credit',
            convertionMultiplier: 100,
            operatorCode: 'Mega888',
            backURL: 'http://www.google.com',
            logoutURL: 'http://www.w3schools.com',
            menuConfig: {
                menuName: 'Mega888',
                buttons: [
                    {
                        name: 'btnBack',
                        active: true,
                    },
                    {
                        name: 'btnHelp',
                        active: true,
                    },
                    {
                        name: 'btnAudio',
                        active: true,
                    },
                    {
                        name: 'btnShake',
                        active: false,
                    },
                    {
                        name: 'btnLogout',
                        active: true,
                    },
                ],
            },
            moduleList: [
                // {   to-be migrate to http assets bundle
                //     moduleCode: 'menu',
                //     version: '',
                //     bundleURL: 'http://127.0.0.7:8088/build/web-mobile/assets/kiss918-menu',
                //     bundleName: 'kiss918-menu',
                //     bundlePrefabPath: 'prefabs/Kiss915MenuPrefab',
                // },
                // {
                //     moduleCode: 'menu',
                //     version: '10a61',
                //     // bundleURL: 'http://127.0.0.7:8088/build/web-mobile/assets/mega888-menu',
                //     bundleURL: 'https://gt3-game.github.io/super-template-modules-hosting/bundles/mega888-menu',
                //     bundleName: 'mega888-menu',
                //     bundlePrefabPath: 'prefabs/MenuPrefab',
                // },
                // {   to-be migrate to http assets bundle
                //     moduleCode: 'jackpot',
                //     version: '',
                //     bundleURL: 'http://127.0.0.7:8088/build/web-mobile/assets/jackpot',
                //     bundleName: 'jackpot',
                //     bundlePrefabPath: 'prefabs/JackpotPanelPrefab',
                // },
                // {   to-be migrate to http assets bundle
                //     moduleCode: 'dollarball',
                //     version: '',
                //     bundleURL: 'http://127.0.0.7:8088/build/web-mobile/assets/dollar-ball',
                //     bundleName: 'dollar-ball',
                //     bundlePrefabPath: 'prefabs/DollarBallPanelPrefab',
                // },
            ],
        };

        RegisterDeviceFullScreen();

        GameSystemManager.getInstance().setConfig(dummyGameConfig);
        GameSystemManager.getInstance().setFPS(30);
        GameSystemManager.getInstance().setDownloadConcurrency();

        // Initialize the log manager
        gg.logger.init({
            enableLog: CC_DEBUG,
        });

        // Initialize the panel router
        gg.panelRouter.init(this.rootLayerNode, true);
    }

    async start() {
        // Add Bundle Check Point - step 2
        // Load Bundle
        const moduleList = ModuleManager.getInstance().getModuleList();

        // Base bundles
        let bundleList = [
            {
                level: 1,
                version: undefined,
                bundleURL: BundleConfigs.GameBundle,
            },
            {
                level: 2,
                version: undefined,
                bundleURL: BundleConfigs.CommonBundle,
            },
        ];

        bundleList = bundleList.concat(moduleList);

        await AsyncTask(async (resolve) => {
            for (let i = 0, len = bundleList.length; i < len; i++) {
                const load = bundleList[i];

                await AssetLoader.loadBundle(load.bundleURL, load.version);
            }

            resolve();
        });

        // await AssetLoader.loadBundle(BundleConfigs.GameBundle);
        // await AssetLoader.loadBundle(BundleConfigs.CommonBundle);

        // Gamble Module WIP and Ignore It first.
        // await AssetLoader.loadBundle(BundleConfigs.JackpotBundle);
        // await AssetLoader.loadBundle(BundleConfigs.DollarBallBundle);
        // await AssetLoader.loadBundle(BundleConfigs.GambleRedBackBundle);
        // await AssetLoader.loadBundle(BundleConfigs.GambleHighCardBundle);
        // await AssetLoader.loadBundle(BundleConfigs.GambleDiceBundle);
        // await AssetLoader.loadBundle(BundleConfigs.GambleCoinBundle);

        // Load boot page
        await gg.panelRouter.loadAsync(PanelConfigs.bootPanel);

        // Open the boot page
        gg.panelRouter.show({
            panel: PanelConfigs.bootPanel,
        });
    }
}
