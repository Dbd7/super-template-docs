export enum HUDStatus {
    Active = 1,
    Inactive = 2,
}

export enum TurboStatus {
    Active = 1,
    Inactive = 2,
}

export enum AutoSpinStatus {
    Active = 1,
    Inactive = 2,
}
