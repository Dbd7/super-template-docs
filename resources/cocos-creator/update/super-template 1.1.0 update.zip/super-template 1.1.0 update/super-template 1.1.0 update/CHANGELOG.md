# ChangeLog

## 1.1.0

-   Added Dynamic Modules Loader
-   Added Fullsceeen Control
-   Added GameServer Manager to Call API
-   Update Swipe and Spin Feature
-   Bugs Fixed

## 1.0.0

-   Initialize Super-Template
