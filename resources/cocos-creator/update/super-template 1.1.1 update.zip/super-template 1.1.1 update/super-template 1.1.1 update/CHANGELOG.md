# ChangeLog

## 1.1.1

- Added modules-config.json handler
- Added Insufficient Balance Message
- Added GlobaData.ts
- Fixed issue when showing help-information panel still able to spin using keyboard space key
- Fixed Incorrect Balance Display
- Fixed Post big win sfx need to cut when reset function apply
- Update API http to https

## 1.1.0

- Added Dynamic Modules Loader
- Added Fullsceeen Control
- Added GameServer Manager to Call API
- Update Swipe and Spin Feature
- Bugs Fixed

## 1.0.0

- Initialize Super-Template
